import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { BookSearch } from "./user/BookSearch";
import { MyBorrowings } from "./user/MyBorrowings";
import { Recommendations } from "./user/Recommendations";
import { ChatAssistant } from "./user/ChatAssistant";
import { UserProfile } from "./user/UserProfile";

type TabType = "search" | "borrowings" | "recommendations" | "chat" | "profile";

export function UserDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("search");
  const userProfile = useQuery(api.users.getCurrentUserProfile);
  const currentBorrowings = useQuery(api.borrowing.getCurrentBorrowings);
  const notifications = useQuery(api.notifications.getUserNotifications, {
    unreadOnly: true,
    limit: 5,
  });

  const tabs = [
    { id: "search" as const, label: "Search Books", icon: "🔍" },
    { id: "borrowings" as const, label: "My Books", icon: "📚", badge: currentBorrowings?.length },
    { id: "recommendations" as const, label: "Recommendations", icon: "⭐" },
    { id: "chat" as const, label: "AI Assistant", icon: "🤖" },
    { id: "profile" as const, label: "Profile", icon: "👤", badge: notifications?.length },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Library Portal</h2>
          <p className="text-sm text-gray-600 mt-1">
            Welcome, {userProfile?.firstName}
          </p>
          {userProfile?.fineAmount && userProfile.fineAmount > 0 && (
            <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded">
              <p className="text-xs text-red-600">
                Outstanding Fine: ${userProfile.fineAmount.toFixed(2)}
              </p>
            </div>
          )}
        </div>
        
        <nav className="mt-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center justify-between px-6 py-3 text-left hover:bg-blue-50 transition-colors ${
                activeTab === tab.id
                  ? "bg-blue-50 border-r-2 border-blue-500 text-blue-700"
                  : "text-gray-700"
              }`}
            >
              <div className="flex items-center">
                <span className="mr-3 text-lg">{tab.icon}</span>
                {tab.label}
              </div>
              {tab.badge && tab.badge > 0 && (
                <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1 min-w-[20px] text-center">
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {activeTab === "search" && <BookSearch />}
          {activeTab === "borrowings" && <MyBorrowings />}
          {activeTab === "recommendations" && <Recommendations />}
          {activeTab === "chat" && <ChatAssistant />}
          {activeTab === "profile" && <UserProfile />}
        </div>
      </div>
    </div>
  );
}
