import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { toast } from "sonner";

export function Recommendations() {
  const [aiQuery, setAiQuery] = useState("");
  const [aiResults, setAiResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const personalizedRecs = useQuery(api.recommendations.getPersonalizedRecommendations, { limit: 6 });
  const popularBooks = useQuery(api.books.getPopularBooks, { limit: 6 });
  const trendingBooks = useQuery(api.recommendations.getTrendingBooks, { limit: 6 });
  const newArrivals = useQuery(api.recommendations.getNewArrivals, { limit: 6 });

  const aiBookSearch = useMutation(api.recommendations.aiBookSearch as any);
  const borrowBook = useMutation(api.borrowing.borrowBook);
  const reserveBook = useMutation(api.borrowing.reserveBook);

  const handleAiSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuery.trim()) return;

    setIsSearching(true);
    try {
      const results = await aiBookSearch({ query: aiQuery });
      setAiResults(results);
    } catch (error) {
      toast.error("AI search failed: " + (error as Error).message);
    } finally {
      setIsSearching(false);
    }
  };

  const handleBorrow = async (bookId: string) => {
    try {
      await borrowBook({ bookId: bookId as any });
      toast.success("Book borrowed successfully!");
    } catch (error) {
      toast.error("Failed to borrow book: " + (error as Error).message);
    }
  };

  const handleReserve = async (bookId: string) => {
    try {
      await reserveBook({ bookId: bookId as any });
      toast.success("Book reserved successfully!");
    } catch (error) {
      toast.error("Failed to reserve book: " + (error as Error).message);
    }
  };

  const BookCard = ({ book }: { book: any }) => (
    <div className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow">
      <h3 className="text-lg font-semibold text-gray-900 mb-1 line-clamp-2">{book.title}</h3>
      <p className="text-gray-600 mb-2">by {book.author}</p>
      <p className="text-sm text-gray-500 mb-3">{book.genre}</p>
      
      <div className="flex items-center justify-between mb-3">
        <span className={`text-sm font-medium ${
          book.availableCopies > 0 ? 'text-green-600' : 'text-red-600'
        }`}>
          {book.availableCopies > 0 
            ? `${book.availableCopies} available` 
            : 'Out of stock'
          }
        </span>
      </div>

      <div className="flex space-x-2">
        {book.availableCopies > 0 ? (
          <button
            onClick={() => handleBorrow(book._id)}
            className="flex-1 bg-green-600 text-white py-2 px-3 rounded text-sm hover:bg-green-700 transition-colors"
          >
            Borrow
          </button>
        ) : (
          <button
            onClick={() => handleReserve(book._id)}
            className="flex-1 bg-yellow-600 text-white py-2 px-3 rounded text-sm hover:bg-yellow-700 transition-colors"
          >
            Reserve
          </button>
        )}
      </div>
    </div>
  );

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Book Recommendations</h1>

      {/* AI-Powered Search */}
      <div className="mb-8 bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">🤖 AI Book Search</h2>
        <p className="text-gray-600 mb-4">
          Ask me anything! "I want a mystery novel set in Victorian London" or "Books similar to Harry Potter"
        </p>
        <form onSubmit={handleAiSearch} className="flex space-x-3">
          <input
            type="text"
            value={aiQuery}
            onChange={(e) => setAiQuery(e.target.value)}
            placeholder="Describe what kind of book you're looking for..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={isSearching}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {isSearching ? "Searching..." : "Search"}
          </button>
        </form>

        {aiResults.length > 0 && (
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">AI Search Results</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {aiResults.map((book) => (
                <BookCard key={book._id} book={book} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Personalized Recommendations */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">⭐ Recommended for You</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {personalizedRecs?.map((book) => (
            <BookCard key={book._id} book={book} />
          ))}
        </div>
      </div>

      {/* Trending Books */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">🔥 Trending This Week</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trendingBooks?.filter(book => book !== null).map((book) => (
            <BookCard key={book!._id} book={book} />
          ))}
        </div>
      </div>

      {/* Popular Books */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">📈 Popular Books</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularBooks?.filter(book => book !== null).map((book) => (
            <BookCard key={book!._id} book={book} />
          ))}
        </div>
      </div>

      {/* New Arrivals */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">🆕 New Arrivals</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {newArrivals?.map((book) => (
            <BookCard key={book._id} book={book} />
          ))}
        </div>
      </div>
    </div>
  );
}
