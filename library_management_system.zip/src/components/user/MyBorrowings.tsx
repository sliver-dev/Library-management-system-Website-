import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { toast } from "sonner";

export function MyBorrowings() {
  const currentBorrowings = useQuery(api.borrowing.getCurrentBorrowings);
  const reservations = useQuery(api.borrowing.getUserReservations);
  const borrowingHistory = useQuery(api.users.getUserBorrowingHistory, { limit: 10 });

  const returnBook = useMutation(api.borrowing.returnBook);
  const renewBook = useMutation(api.borrowing.renewBook);

  const handleReturn = async (recordId: string) => {
    try {
      const result = await returnBook({ recordId: recordId as any });
      if (result.fineAmount > 0) {
        toast.success(`Book returned! Fine: $${result.fineAmount.toFixed(2)}`);
      } else {
        toast.success("Book returned successfully!");
      }
    } catch (error) {
      toast.error("Failed to return book: " + (error as Error).message);
    }
  };

  const handleRenew = async (recordId: string) => {
    try {
      await renewBook({ recordId: recordId as any });
      toast.success("Book renewed successfully!");
    } catch (error) {
      toast.error("Failed to renew book: " + (error as Error).message);
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-6">My Books</h1>

      {/* Current Borrowings */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Currently Borrowed</h2>
        {currentBorrowings && currentBorrowings.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <p className="text-gray-500">You have no books currently borrowed.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {currentBorrowings?.map((borrowing) => (
              <div key={borrowing._id} className={`bg-white rounded-lg shadow-md p-6 ${
                borrowing.isOverdue ? 'border-l-4 border-red-500' : ''
              }`}>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {borrowing.book?.title}
                </h3>
                <p className="text-gray-600 mb-2">by {borrowing.book?.author}</p>
                <div className="space-y-1 text-sm text-gray-500 mb-4">
                  <p>Borrowed: {new Date(borrowing.borrowDate).toLocaleDateString()}</p>
                  <p className={borrowing.isOverdue ? 'text-red-600 font-medium' : ''}>
                    Due: {new Date(borrowing.dueDate).toLocaleDateString()}
                    {borrowing.isOverdue && ` (${borrowing.daysOverdue} days overdue)`}
                  </p>
                  <p>Renewals: {borrowing.renewalCount}/2</p>
                </div>
                
                {borrowing.isOverdue && (
                  <div className="bg-red-50 border border-red-200 rounded p-3 mb-4">
                    <p className="text-red-700 text-sm font-medium">
                      This book is overdue! Fine: ${(borrowing.daysOverdue * 1).toFixed(2)}
                    </p>
                  </div>
                )}

                <div className="flex space-x-2">
                  <button
                    onClick={() => handleReturn(borrowing._id)}
                    className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                  >
                    Return
                  </button>
                  {borrowing.renewalCount < 2 && !borrowing.isOverdue && (
                    <button
                      onClick={() => handleRenew(borrowing._id)}
                      className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors text-sm"
                    >
                      Renew
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Reservations */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">My Reservations</h2>
        {reservations && reservations.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <p className="text-gray-500">You have no active reservations.</p>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Book
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Reserved Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Queue Position
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Expires
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {reservations?.map((reservation) => (
                    <tr key={reservation._id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {reservation.book?.title}
                          </div>
                          <div className="text-sm text-gray-500">
                            by {reservation.book?.author}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {new Date(reservation.reservationDate).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                          #{reservation.queuePosition}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {new Date(reservation.expiryDate).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Borrowing History */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent History</h2>
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Book
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Borrowed
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Returned
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {borrowingHistory?.map((record) => (
                  <tr key={record._id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {record.book?.title}
                        </div>
                        <div className="text-sm text-gray-500">
                          by {record.book?.author}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(record.borrowDate).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {record.returnDate 
                        ? new Date(record.returnDate).toLocaleDateString()
                        : '-'
                      }
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        record.status === 'returned' 
                          ? 'bg-green-100 text-green-800'
                          : record.status === 'overdue'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
