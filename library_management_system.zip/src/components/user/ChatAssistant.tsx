import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { toast } from "sonner";

export function ChatAssistant() {
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chatSession = useQuery(api.chat.getChatSession, 
    currentSessionId ? { sessionId: currentSessionId } : "skip"
  );
  const chatSessions = useQuery(api.chat.getUserChatSessions, { limit: 5 });

  const startChatSession = useMutation(api.chat.startChatSession);
  const sendChatMessage = useMutation(api.chat.sendChatMessage as any);
  const endChatSession = useMutation(api.chat.endChatSession);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatSession?.messages]);

  const handleStartNewChat = async () => {
    try {
      const result = await startChatSession();
      setCurrentSessionId(result.sessionId);
    } catch (error) {
      toast.error("Failed to start chat session");
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !currentSessionId || isLoading) return;

    setIsLoading(true);
    try {
      await sendChatMessage({
        sessionId: currentSessionId,
        message: message.trim(),
      });
      setMessage("");
    } catch (error) {
      toast.error("Failed to send message");
    } finally {
      setIsLoading(false);
    }
  };

  const handleEndChat = async () => {
    if (!currentSessionId) return;
    
    try {
      await endChatSession({ sessionId: currentSessionId });
      setCurrentSessionId(null);
      toast.success("Chat session ended");
    } catch (error) {
      toast.error("Failed to end chat session");
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">AI Library Assistant</h1>
        <div className="flex space-x-3">
          <button
            onClick={handleStartNewChat}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            New Chat
          </button>
          {currentSessionId && (
            <button
              onClick={handleEndChat}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
            >
              End Chat
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 flex space-x-6">
        {/* Chat History Sidebar */}
        <div className="w-64 bg-white rounded-lg shadow-md p-4">
          <h3 className="font-semibold text-gray-900 mb-3">Recent Chats</h3>
          <div className="space-y-2">
            {chatSessions?.map((session) => (
              <button
                key={session.sessionId}
                onClick={() => setCurrentSessionId(session.sessionId)}
                className={`w-full text-left p-3 rounded-lg transition-colors ${
                  currentSessionId === session.sessionId
                    ? 'bg-blue-50 border border-blue-200'
                    : 'hover:bg-gray-50'
                }`}
              >
                <div className="text-sm font-medium text-gray-900 truncate">
                  {session.lastMessage?.content.slice(0, 30)}...
                </div>
                <div className="text-xs text-gray-500">
                  {new Date(session.createdAt).toLocaleDateString()}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Chat Interface */}
        <div className="flex-1 bg-white rounded-lg shadow-md flex flex-col">
          {!currentSessionId ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl mb-4">🤖</div>
                <h2 className="text-2xl font-semibold text-gray-900 mb-2">
                  Welcome to AI Library Assistant
                </h2>
                <p className="text-gray-600 mb-6 max-w-md">
                  I can help you find books, check due dates, calculate fines, 
                  and answer questions about library services.
                </p>
                <button
                  onClick={handleStartNewChat}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Start New Chat
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {chatSession?.messages.map((msg, index) => (
                  <div
                    key={index}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        msg.role === 'user'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <p className="text-xs opacity-75 mt-1">
                        {new Date(msg.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 text-gray-900 max-w-xs lg:max-w-md px-4 py-2 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600"></div>
                        <span className="text-sm">AI is thinking...</span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input */}
              <div className="border-t p-4">
                <form onSubmit={handleSendMessage} className="flex space-x-3">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Ask me anything about the library..."
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    disabled={isLoading}
                  />
                  <button
                    type="submit"
                    disabled={isLoading || !message.trim()}
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                  >
                    Send
                  </button>
                </form>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
