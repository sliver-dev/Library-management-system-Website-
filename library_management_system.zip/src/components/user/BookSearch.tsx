import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { toast } from "sonner";

export function BookSearch() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("");
  const [selectedBook, setSelectedBook] = useState<any>(null);

  const books = useQuery(api.books.searchBooks, {
    searchTerm: searchTerm || undefined,
    genre: selectedGenre || undefined,
    availableOnly: true,
  });

  const borrowBook = useMutation(api.borrowing.borrowBook);
  const reserveBook = useMutation(api.borrowing.reserveBook);

  const genres = [
    "Fiction", "Non-Fiction", "Science Fiction", "Fantasy", "Mystery", 
    "Romance", "Thriller", "Biography", "History", "Science", "Technology"
  ];

  const handleBorrow = async (bookId: string) => {
    try {
      await borrowBook({ bookId: bookId as any });
      toast.success("Book borrowed successfully!");
      setSelectedBook(null);
    } catch (error) {
      toast.error("Failed to borrow book: " + (error as Error).message);
    }
  };

  const handleReserve = async (bookId: string) => {
    try {
      await reserveBook({ bookId: bookId as any });
      toast.success("Book reserved successfully!");
      setSelectedBook(null);
    } catch (error) {
      toast.error("Failed to reserve book: " + (error as Error).message);
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Search Books</h1>

      {/* Search Controls */}
      <div className="mb-6 space-y-4">
        <input
          type="text"
          placeholder="Search by title, author, or ISBN..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <select
          value={selectedGenre}
          onChange={(e) => setSelectedGenre(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Genres</option>
          {genres.map((genre) => (
            <option key={genre} value={genre}>{genre}</option>
          ))}
        </select>
      </div>

      {/* Books Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {books?.map((book) => (
          <div key={book._id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{book.title}</h3>
            <p className="text-gray-600 mb-2">by {book.author}</p>
            <p className="text-sm text-gray-500 mb-2">{book.genre} • {book.publishedYear}</p>
            <p className="text-sm text-gray-500 mb-4">ISBN: {book.isbn}</p>
            
            {book.description && (
              <p className="text-sm text-gray-700 mb-4 line-clamp-3">{book.description}</p>
            )}
            
            <div className="flex items-center justify-between mb-4">
              <span className={`text-sm font-medium ${
                book.availableCopies > 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {book.availableCopies > 0 
                  ? `${book.availableCopies} available` 
                  : 'Out of stock'
                }
              </span>
            </div>

            <div className="flex space-x-2">
              <button
                onClick={() => setSelectedBook(book)}
                className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                View Details
              </button>
              {book.availableCopies > 0 ? (
                <button
                  onClick={() => handleBorrow(book._id)}
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors text-sm"
                >
                  Borrow
                </button>
              ) : (
                <button
                  onClick={() => handleReserve(book._id)}
                  className="flex-1 bg-yellow-600 text-white py-2 px-4 rounded-lg hover:bg-yellow-700 transition-colors text-sm"
                >
                  Reserve
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Book Details Modal */}
      {selectedBook && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4">{selectedBook.title}</h2>
            <div className="space-y-3 mb-6">
              <p><strong>Author:</strong> {selectedBook.author}</p>
              <p><strong>Genre:</strong> {selectedBook.genre}</p>
              <p><strong>Published:</strong> {selectedBook.publishedYear}</p>
              <p><strong>Edition:</strong> {selectedBook.edition}</p>
              <p><strong>ISBN:</strong> {selectedBook.isbn}</p>
              <p><strong>Available Copies:</strong> {selectedBook.availableCopies} / {selectedBook.totalCopies}</p>
              {selectedBook.description && (
                <div>
                  <strong>Description:</strong>
                  <p className="mt-1 text-gray-700">{selectedBook.description}</p>
                </div>
              )}
              {selectedBook.tags && selectedBook.tags.length > 0 && (
                <div>
                  <strong>Tags:</strong>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {selectedBook.tags.map((tag: string, index: number) => (
                      <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setSelectedBook(null)}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Close
              </button>
              {selectedBook.availableCopies > 0 ? (
                <button
                  onClick={() => handleBorrow(selectedBook._id)}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Borrow Book
                </button>
              ) : (
                <button
                  onClick={() => handleReserve(selectedBook._id)}
                  className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700"
                >
                  Reserve Book
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
