import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { toast } from "sonner";

export function UserProfile() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
    address: "",
    preferences: {
      favoriteGenres: [] as string[],
      notificationSettings: {
        email: true,
        sms: false,
        dueDateReminders: true,
      },
    },
  });

  const userProfile = useQuery(api.users.getCurrentUserProfile);
  const notifications = useQuery(api.notifications.getUserNotifications, { limit: 10 });
  const borrowingHistory = useQuery(api.users.getUserBorrowingHistory, { limit: 5 });

  const updateUserProfile = useMutation(api.users.updateUserProfile);
  const markNotificationAsRead = useMutation(api.notifications.markNotificationAsRead);
  const markAllNotificationsAsRead = useMutation(api.notifications.markAllNotificationsAsRead);

  const genres = [
    "Fiction", "Non-Fiction", "Science Fiction", "Fantasy", "Mystery", 
    "Romance", "Thriller", "Biography", "History", "Science", "Technology"
  ];

  // Initialize form data when profile loads
  useState(() => {
    if (userProfile) {
      setFormData({
        firstName: userProfile.firstName || "",
        lastName: userProfile.lastName || "",
        phoneNumber: userProfile.phoneNumber || "",
        address: userProfile.address || "",
        preferences: userProfile.preferences || {
          favoriteGenres: [],
          notificationSettings: {
            email: true,
            sms: false,
            dueDateReminders: true,
          },
        },
      });
    }
  });

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateUserProfile(formData);
      setIsEditing(false);
      toast.success("Profile updated successfully!");
    } catch (error) {
      toast.error("Failed to update profile: " + (error as Error).message);
    }
  };

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await markNotificationAsRead({ notificationId: notificationId as any });
    } catch (error) {
      toast.error("Failed to mark notification as read");
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      const count = await markAllNotificationsAsRead();
      toast.success(`Marked ${count} notifications as read`);
    } catch (error) {
      toast.error("Failed to mark notifications as read");
    }
  };

  const handleGenreToggle = (genre: string) => {
    const currentGenres = formData.preferences.favoriteGenres;
    const newGenres = currentGenres.includes(genre)
      ? currentGenres.filter(g => g !== genre)
      : [...currentGenres, genre];
    
    setFormData({
      ...formData,
      preferences: {
        ...formData.preferences,
        favoriteGenres: newGenres,
      },
    });
  };

  if (!userProfile) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-6">My Profile</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Information */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Profile Information</h2>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                {isEditing ? "Cancel" : "Edit Profile"}
              </button>
            </div>

            {isEditing ? (
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="First Name"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                  <input
                    type="text"
                    placeholder="Last Name"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <textarea
                  placeholder="Address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  rows={3}
                />

                {/* Favorite Genres */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Favorite Genres
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {genres.map((genre) => (
                      <label key={genre} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={formData.preferences.favoriteGenres.includes(genre)}
                          onChange={() => handleGenreToggle(genre)}
                          className="mr-2"
                        />
                        <span className="text-sm">{genre}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Notification Settings */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Notification Preferences
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.preferences.notificationSettings.email}
                        onChange={(e) => setFormData({
                          ...formData,
                          preferences: {
                            ...formData.preferences,
                            notificationSettings: {
                              ...formData.preferences.notificationSettings,
                              email: e.target.checked,
                            },
                          },
                        })}
                        className="mr-2"
                      />
                      <span className="text-sm">Email notifications</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.preferences.notificationSettings.dueDateReminders}
                        onChange={(e) => setFormData({
                          ...formData,
                          preferences: {
                            ...formData.preferences,
                            notificationSettings: {
                              ...formData.preferences.notificationSettings,
                              dueDateReminders: e.target.checked,
                            },
                          },
                        })}
                        className="mr-2"
                      />
                      <span className="text-sm">Due date reminders</span>
                    </label>
                  </div>
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Name</label>
                    <p className="text-gray-900">{userProfile.firstName} {userProfile.lastName}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Email</label>
                    <p className="text-gray-900">{userProfile.email}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Phone</label>
                    <p className="text-gray-900">{userProfile.phoneNumber || "Not provided"}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Role</label>
                    <p className="text-gray-900 capitalize">{userProfile.role}</p>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-500">Address</label>
                  <p className="text-gray-900">{userProfile.address || "Not provided"}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-500">Member Since</label>
                  <p className="text-gray-900">
                    {new Date(userProfile.membershipDate).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-500">Favorite Genres</label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {userProfile.preferences.favoriteGenres.map((genre: string) => (
                      <span key={genre} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                        {genre}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Account Status */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Account Status</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <p className="text-2xl font-bold text-blue-600">{userProfile.maxBooksAllowed}</p>
                <p className="text-sm text-blue-600">Books Allowed</p>
              </div>
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <p className="text-2xl font-bold text-red-600">${userProfile.fineAmount.toFixed(2)}</p>
                <p className="text-sm text-red-600">Outstanding Fines</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <p className="text-2xl font-bold text-green-600">
                  {userProfile.isActive ? "Active" : "Inactive"}
                </p>
                <p className="text-sm text-green-600">Account Status</p>
              </div>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Notifications</h2>
              {notifications && notifications.some(n => !n.isRead) && (
                <button
                  onClick={handleMarkAllAsRead}
                  className="text-sm text-blue-600 hover:text-blue-800"
                >
                  Mark all as read
                </button>
              )}
            </div>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {notifications?.map((notification) => (
                <div
                  key={notification._id}
                  className={`p-3 rounded-lg border ${
                    notification.isRead 
                      ? 'bg-gray-50 border-gray-200' 
                      : 'bg-blue-50 border-blue-200'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 text-sm">
                        {notification.title}
                      </h4>
                      <p className="text-sm text-gray-600 mt-1">
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(notification.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    {!notification.isRead && (
                      <button
                        onClick={() => handleMarkAsRead(notification._id)}
                        className="text-xs text-blue-600 hover:text-blue-800 ml-2"
                      >
                        Mark read
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {notifications?.length === 0 && (
                <p className="text-gray-500 text-center py-4">No notifications</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
