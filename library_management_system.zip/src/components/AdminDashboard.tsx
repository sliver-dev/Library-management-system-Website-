import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { DashboardStats } from "./admin/DashboardStats";
import { BookManagement } from "./admin/BookManagement";
import { UserManagement } from "./admin/UserManagement";
import { Analytics } from "./admin/Analytics";
import { OverdueBooks } from "./admin/OverdueBooks";

type TabType = "dashboard" | "books" | "users" | "analytics" | "overdue";

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("dashboard");
  const userProfile = useQuery(api.users.getCurrentUserProfile);

  const tabs = [
    { id: "dashboard" as const, label: "Dashboard", icon: "📊" },
    { id: "books" as const, label: "Books", icon: "📚" },
    { id: "users" as const, label: "Users", icon: "👥" },
    { id: "analytics" as const, label: "Analytics", icon: "📈" },
    { id: "overdue" as const, label: "Overdue", icon: "⚠️" },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Admin Panel</h2>
          <p className="text-sm text-gray-600 mt-1">
            Welcome, {userProfile?.firstName}
          </p>
        </div>
        
        <nav className="mt-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center px-6 py-3 text-left hover:bg-blue-50 transition-colors ${
                activeTab === tab.id
                  ? "bg-blue-50 border-r-2 border-blue-500 text-blue-700"
                  : "text-gray-700"
              }`}
            >
              <span className="mr-3 text-lg">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {activeTab === "dashboard" && <DashboardStats />}
          {activeTab === "books" && <BookManagement />}
          {activeTab === "users" && <UserManagement />}
          {activeTab === "analytics" && <Analytics />}
          {activeTab === "overdue" && <OverdueBooks />}
        </div>
      </div>
    </div>
  );
}
