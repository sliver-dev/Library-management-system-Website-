import { useQuery } from "convex/react";
import { api } from "../../../convex/_generated/api";

export function DashboardStats() {
  const stats = useQuery(api.analytics.getDashboardStats);

  if (!stats) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const statCards = [
    {
      title: "Total Books",
      value: stats.totalBooks,
      icon: "📚",
      color: "bg-blue-500",
    },
    {
      title: "Total Users",
      value: stats.totalUsers,
      icon: "👥",
      color: "bg-green-500",
    },
    {
      title: "Active Borrowings",
      value: stats.activeBorrowings,
      icon: "📖",
      color: "bg-yellow-500",
    },
    {
      title: "Overdue Books",
      value: stats.overdueBooks,
      icon: "⚠️",
      color: "bg-red-500",
    },
    {
      title: "Total Fines",
      value: `$${stats.totalFines.toFixed(2)}`,
      icon: "💰",
      color: "bg-purple-500",
    },
    {
      title: "Availability Rate",
      value: `${stats.availabilityRate}%`,
      icon: "📊",
      color: "bg-indigo-500",
    },
  ];

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Dashboard Overview</h1>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {statCards.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
              <div className={`${stat.color} rounded-full p-3 text-white text-2xl`}>
                {stat.icon}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Today's Activity */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Today's Activity</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
            <div>
              <p className="text-sm text-green-600">Books Issued Today</p>
              <p className="text-2xl font-bold text-green-700">{stats.todaysBorrowings}</p>
            </div>
            <div className="text-green-500 text-3xl">📤</div>
          </div>
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
            <div>
              <p className="text-sm text-blue-600">Books Returned Today</p>
              <p className="text-2xl font-bold text-blue-700">{stats.todaysReturns}</p>
            </div>
            <div className="text-blue-500 text-3xl">📥</div>
          </div>
        </div>
      </div>
    </div>
  );
}
