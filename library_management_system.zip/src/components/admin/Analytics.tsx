import { useQuery } from "convex/react";
import { api } from "../../../convex/_generated/api";

export function Analytics() {
  const borrowingTrends = useQuery(api.analytics.getBorrowingTrends, { days: 30 });
  const popularBooks = useQuery(api.analytics.getPopularBooksAnalytics, { limit: 10 });
  const genreAnalytics = useQuery(api.analytics.getGenreAnalytics, { days: 30 });
  const userActivity = useQuery(api.analytics.getUserActivityAnalytics, { days: 30 });

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Analytics</h1>

      {/* User Activity Stats */}
      {userActivity && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Active Users</h3>
            <p className="text-3xl font-bold text-blue-600">{userActivity.activeUsers}</p>
            <p className="text-sm text-gray-500">Last 30 days</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">New Registrations</h3>
            <p className="text-3xl font-bold text-green-600">{userActivity.newRegistrations}</p>
            <p className="text-sm text-gray-500">Last 30 days</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Users with Fines</h3>
            <p className="text-3xl font-bold text-red-600">{userActivity.usersWithFines}</p>
            <p className="text-sm text-gray-500">${userActivity.totalFineAmount.toFixed(2)} total</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Avg Books/User</h3>
            <p className="text-3xl font-bold text-purple-600">{userActivity.avgBooksPerUser}</p>
            <p className="text-sm text-gray-500">Active users</p>
          </div>
        </div>
      )}

      {/* Popular Books */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Popular Books (30 days)</h2>
          <div className="space-y-3">
            {popularBooks?.slice(0, 5).map((book, index) => (
              book && (
                <div key={book._id} className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{(book as any).title}</p>
                    <p className="text-sm text-gray-500">by {(book as any).author}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-blue-600">{book.borrowCount}</p>
                    <p className="text-xs text-gray-500">borrows</p>
                  </div>
                </div>
              )
            ))}
          </div>
        </div>

        {/* Genre Analytics */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Popular Genres (30 days)</h2>
          <div className="space-y-3">
            {genreAnalytics?.slice(0, 5).map((genre, index) => (
              <div key={genre.genre} className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{genre.genre}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-green-600">{genre.count}</p>
                  <p className="text-xs text-gray-500">borrows</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Borrowing Trends Chart */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Borrowing Trends (30 days)</h2>
        <div className="h-64 flex items-end space-x-1">
          {borrowingTrends?.slice(-14).map((day, index) => (
            <div key={day.date} className="flex-1 flex flex-col items-center">
              <div className="w-full bg-blue-200 rounded-t" style={{ height: `${(day.borrowings / Math.max(...borrowingTrends.map(d => d.borrowings))) * 200}px` }}>
                <div className="w-full bg-blue-500 rounded-t" style={{ height: `${(day.borrowings / Math.max(...borrowingTrends.map(d => d.borrowings))) * 200}px` }}></div>
              </div>
              <p className="text-xs text-gray-500 mt-1 transform -rotate-45 origin-top-left">
                {new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
