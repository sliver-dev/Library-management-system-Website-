import { query, mutation, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Helper function to get user profile
async function getUserProfile(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  
  const profile = await ctx.db
    .query("userProfiles")
    .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
    .unique();
  
  if (!profile) throw new Error("User profile not found");
  return { userId, profile };
}

// Get dashboard statistics (Admin only)
export const getDashboardStats = query({
  args: {},
  handler: async (ctx) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view dashboard stats");
    }
    
    // Get total counts
    const totalBooks = await ctx.db.query("books").collect();
    const totalUsers = await ctx.db.query("userProfiles").collect();
    const activeBorrowings = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_status", (q) => q.eq("status", "borrowed"))
      .collect();
    const overdueBooks = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_status", (q) => q.eq("status", "overdue"))
      .collect();
    
    // Calculate total fines
    const totalFines = totalUsers.reduce((sum, user) => sum + user.fineAmount, 0);
    
    // Get today's activity
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStart = today.getTime();
    const todayEnd = todayStart + 24 * 60 * 60 * 1000;
    
    const todaysBorrowings = await ctx.db
      .query("borrowingRecords")
      .filter((q) => 
        q.and(
          q.gte(q.field("borrowDate"), todayStart),
          q.lt(q.field("borrowDate"), todayEnd)
        )
      )
      .collect();
    
    const todaysReturns = await ctx.db
      .query("borrowingRecords")
      .filter((q) => 
        q.and(
          q.gte(q.field("returnDate"), todayStart),
          q.lt(q.field("returnDate"), todayEnd)
        )
      )
      .collect();
    
    // Calculate availability rate
    const totalCopies = totalBooks.reduce((sum, book) => sum + book.totalCopies, 0);
    const availableCopies = totalBooks.reduce((sum, book) => sum + book.availableCopies, 0);
    const availabilityRate = totalCopies > 0 ? (availableCopies / totalCopies) * 100 : 0;
    
    return {
      totalBooks: totalBooks.length,
      totalUsers: totalUsers.length,
      activeBorrowings: activeBorrowings.length,
      overdueBooks: overdueBooks.length,
      totalFines,
      todaysBorrowings: todaysBorrowings.length,
      todaysReturns: todaysReturns.length,
      availabilityRate: Math.round(availabilityRate * 100) / 100,
      totalCopies,
      availableCopies,
    };
  },
});

// Get borrowing trends over time
export const getBorrowingTrends = query({
  args: { 
    days: v.optional(v.number()), // Default 30 days
  },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view borrowing trends");
    }
    
    const days = args.days || 30;
    const startDate = Date.now() - (days * 24 * 60 * 60 * 1000);
    
    const borrowings = await ctx.db
      .query("borrowingRecords")
      .filter((q) => q.gte(q.field("borrowDate"), startDate))
      .collect();
    
    const returns = await ctx.db
      .query("borrowingRecords")
      .filter((q) => 
        q.and(
          q.gte(q.field("returnDate"), startDate),
          q.neq(q.field("returnDate"), undefined)
        )
      )
      .collect();
    
    // Group by date
    const trendData = new Map<string, { borrowings: number; returns: number }>();
    
    // Initialize all dates
    for (let i = 0; i < days; i++) {
      const date = new Date(Date.now() - (i * 24 * 60 * 60 * 1000));
      const dateStr = date.toISOString().split('T')[0];
      trendData.set(dateStr, { borrowings: 0, returns: 0 });
    }
    
    // Count borrowings by date
    borrowings.forEach(record => {
      const date = new Date(record.borrowDate).toISOString().split('T')[0];
      const data = trendData.get(date);
      if (data) {
        data.borrowings++;
      }
    });
    
    // Count returns by date
    returns.forEach(record => {
      if (record.returnDate) {
        const date = new Date(record.returnDate).toISOString().split('T')[0];
        const data = trendData.get(date);
        if (data) {
          data.returns++;
        }
      }
    });
    
    // Convert to array and sort by date
    const trends = Array.from(trendData.entries())
      .map(([date, data]) => ({ date, ...data }))
      .sort((a, b) => a.date.localeCompare(b.date));
    
    return trends;
  },
});

// Get popular books analytics
export const getPopularBooksAnalytics = query({
  args: { 
    limit: v.optional(v.number()),
    days: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view book analytics");
    }
    
    const limit = args.limit || 10;
    const days = args.days || 30;
    const startDate = Date.now() - (days * 24 * 60 * 60 * 1000);
    
    const recentBorrowings = await ctx.db
      .query("borrowingRecords")
      .filter((q) => q.gte(q.field("borrowDate"), startDate))
      .collect();
    
    // Count borrowings per book
    const bookCounts = new Map<string, number>();
    recentBorrowings.forEach(record => {
      const count = bookCounts.get(record.bookId) || 0;
      bookCounts.set(record.bookId, count + 1);
    });
    
    // Get top books with details
    const topBookIds = Array.from(bookCounts.entries())
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit);
    
    const popularBooks = await Promise.all(
      topBookIds.map(async ([bookId, borrowCount]) => {
        const book = await ctx.db.get(bookId as any);
        return book ? { ...book, borrowCount } : null;
      })
    );
    
    return popularBooks.filter(Boolean);
  },
});

// Get genre analytics
export const getGenreAnalytics = query({
  args: { days: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view genre analytics");
    }
    
    const days = args.days || 30;
    const startDate = Date.now() - (days * 24 * 60 * 60 * 1000);
    
    const recentBorrowings = await ctx.db
      .query("borrowingRecords")
      .filter((q) => q.gte(q.field("borrowDate"), startDate))
      .collect();
    
    // Get book details for each borrowing
    const genreCounts = new Map<string, number>();
    
    await Promise.all(
      recentBorrowings.map(async (record) => {
        const book = await ctx.db.get(record.bookId);
        if (book) {
          const count = genreCounts.get(book.genre) || 0;
          genreCounts.set(book.genre, count + 1);
        }
      })
    );
    
    // Convert to array and sort
    const genreStats = Array.from(genreCounts.entries())
      .map(([genre, count]) => ({ genre, count }))
      .sort((a, b) => b.count - a.count);
    
    return genreStats;
  },
});

// Get user activity analytics
export const getUserActivityAnalytics = query({
  args: { days: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view user analytics");
    }
    
    const days = args.days || 30;
    const startDate = Date.now() - (days * 24 * 60 * 60 * 1000);
    
    // Get active users (users who borrowed books in the period)
    const recentBorrowings = await ctx.db
      .query("borrowingRecords")
      .filter((q) => q.gte(q.field("borrowDate"), startDate))
      .collect();
    
    const activeUserIds = new Set(recentBorrowings.map(record => record.userId));
    
    // Get new registrations
    const newUsers = await ctx.db
      .query("userProfiles")
      .filter((q) => q.gte(q.field("membershipDate"), startDate))
      .collect();
    
    // Get users with fines
    const usersWithFines = await ctx.db
      .query("userProfiles")
      .filter((q) => q.gt(q.field("fineAmount"), 0))
      .collect();
    
    // Calculate average books per active user
    const totalBorrowings = recentBorrowings.length;
    const avgBooksPerUser = activeUserIds.size > 0 ? totalBorrowings / activeUserIds.size : 0;
    
    return {
      activeUsers: activeUserIds.size,
      newRegistrations: newUsers.length,
      usersWithFines: usersWithFines.length,
      totalFineAmount: usersWithFines.reduce((sum, user) => sum + user.fineAmount, 0),
      avgBooksPerUser: Math.round(avgBooksPerUser * 100) / 100,
    };
  },
});

// Update daily analytics (scheduled)
export const updateDailyAnalytics = internalMutation({
  args: {},
  handler: async (ctx) => {
    const today = new Date().toISOString().split('T')[0];
    
    // Check if today's analytics already exist
    const existingAnalytics = await ctx.db
      .query("analytics")
      .withIndex("by_date", (q) => q.eq("date", today))
      .unique();
    
    if (existingAnalytics) {
      return; // Already updated today
    }
    
    // Calculate today's statistics
    const totalBooks = await ctx.db.query("books").collect();
    const totalUsers = await ctx.db.query("userProfiles").collect();
    
    const todayStart = new Date(today).getTime();
    const todayEnd = todayStart + 24 * 60 * 60 * 1000;
    
    const booksIssued = await ctx.db
      .query("borrowingRecords")
      .filter((q) => 
        q.and(
          q.gte(q.field("borrowDate"), todayStart),
          q.lt(q.field("borrowDate"), todayEnd)
        )
      )
      .collect();
    
    const booksReturned = await ctx.db
      .query("borrowingRecords")
      .filter((q) => 
        q.and(
          q.gte(q.field("returnDate"), todayStart),
          q.lt(q.field("returnDate"), todayEnd)
        )
      )
      .collect();
    
    const overdueBooks = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_status", (q) => q.eq("status", "overdue"))
      .collect();
    
    const newRegistrations = await ctx.db
      .query("userProfiles")
      .filter((q) => 
        q.and(
          q.gte(q.field("membershipDate"), todayStart),
          q.lt(q.field("membershipDate"), todayEnd)
        )
      )
      .collect();
    
    // Calculate fines collected today
    const finesCollected = booksReturned.reduce((sum, record) => sum + record.fineAmount, 0);
    
    // Get popular genres
    const genreCounts = new Map<string, number>();
    await Promise.all(
      booksIssued.map(async (record) => {
        const book = await ctx.db.get(record.bookId);
        if (book) {
          const count = genreCounts.get(book.genre) || 0;
          genreCounts.set(book.genre, count + 1);
        }
      })
    );
    
    const popularGenres = Array.from(genreCounts.entries())
      .map(([genre, count]) => ({ genre, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
    
    // Get top books
    const bookCounts = new Map<string, number>();
    booksIssued.forEach(record => {
      const count = bookCounts.get(record.bookId) || 0;
      bookCounts.set(record.bookId, count + 1);
    });
    
    const topBooks = Array.from(bookCounts.entries())
      .map(([bookId, borrowCount]) => ({ bookId: bookId as any, borrowCount }))
      .sort((a, b) => b.borrowCount - a.borrowCount)
      .slice(0, 5);
    
    // Insert analytics record
    await ctx.db.insert("analytics", {
      date: today,
      totalBooks: totalBooks.length,
      totalUsers: totalUsers.length,
      booksIssued: booksIssued.length,
      booksReturned: booksReturned.length,
      overdueBooks: overdueBooks.length,
      finesCollected,
      newRegistrations: newRegistrations.length,
      popularGenres,
      topBooks,
    });
  },
});

// Get historical analytics
export const getHistoricalAnalytics = query({
  args: { 
    startDate: v.string(),
    endDate: v.string(),
  },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view historical analytics");
    }
    
    const analytics = await ctx.db
      .query("analytics")
      .withIndex("by_date", (q) => 
        q.gte("date", args.startDate).lte("date", args.endDate)
      )
      .collect();
    
    return analytics.sort((a, b) => a.date.localeCompare(b.date));
  },
});
