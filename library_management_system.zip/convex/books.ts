import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Helper function to get user profile
async function getUserProfile(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  
  const profile = await ctx.db
    .query("userProfiles")
    .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
    .unique();
  
  if (!profile) throw new Error("User profile not found");
  return { userId, profile };
}

// Get all books with search and filter capabilities
export const searchBooks = query({
  args: {
    searchTerm: v.optional(v.string()),
    genre: v.optional(v.string()),
    author: v.optional(v.string()),
    availableOnly: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    if (args.searchTerm) {
      const books = await ctx.db
        .query("books")
        .withSearchIndex("search_books", (q: any) =>
          q.search("title", args.searchTerm!)
        )
        .collect();
      
      if (args.availableOnly) {
        return books.filter(book => book.availableCopies > 0);
      }
      return books;
    } else {
      let books;
      if (args.genre) {
        books = await ctx.db.query("books").withIndex("by_genre", (q: any) => q.eq("genre", args.genre!)).collect();
      } else if (args.author) {
        books = await ctx.db.query("books").withIndex("by_author", (q: any) => q.eq("author", args.author!)).collect();
      } else {
        books = await ctx.db.query("books").collect();
      }
      
      if (args.availableOnly) {
        return books.filter(book => book.availableCopies > 0);
      }
      
      return books;
    }
  },
});

// Get book details with availability
export const getBookDetails = query({
  args: { bookId: v.id("books") },
  handler: async (ctx, args) => {
    const book = await ctx.db.get(args.bookId);
    if (!book) return null;
    
    // Get current borrowing records for this book
    const activeBorrowings = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_book", (q) => q.eq("bookId", args.bookId))
      .filter((q) => q.eq(q.field("status"), "borrowed"))
      .collect();
    
    // Get reservations
    const activeReservations = await ctx.db
      .query("reservations")
      .withIndex("by_book", (q) => q.eq("bookId", args.bookId))
      .filter((q) => q.eq(q.field("status"), "active"))
      .collect();
    
    return {
      ...book,
      currentBorrowings: activeBorrowings.length,
      activeReservations: activeReservations.length,
    };
  },
});

// Add new book (Admin only)
export const addBook = mutation({
  args: {
    title: v.string(),
    author: v.string(),
    isbn: v.string(),
    genre: v.string(),
    edition: v.string(),
    publishedYear: v.number(),
    totalCopies: v.number(),
    description: v.optional(v.string()),
    coverImageId: v.optional(v.id("_storage")),
    tags: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const { userId, profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can add books");
    }
    
    const bookId = await ctx.db.insert("books", {
      ...args,
      availableCopies: args.totalCopies,
      addedBy: userId,
    });
    
    return bookId;
  },
});

// Update book details (Admin only)
export const updateBook = mutation({
  args: {
    bookId: v.id("books"),
    title: v.optional(v.string()),
    author: v.optional(v.string()),
    genre: v.optional(v.string()),
    edition: v.optional(v.string()),
    publishedYear: v.optional(v.number()),
    totalCopies: v.optional(v.number()),
    description: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can update books");
    }
    
    const { bookId, ...updates } = args;
    const book = await ctx.db.get(bookId);
    if (!book) throw new Error("Book not found");
    
    // If total copies changed, update available copies proportionally
    if (updates.totalCopies !== undefined) {
      const borrowedCopies = book.totalCopies - book.availableCopies;
      (updates as any).availableCopies = Math.max(0, updates.totalCopies - borrowedCopies);
    }
    
    await ctx.db.patch(bookId, updates);
  },
});

// Remove book (Admin only)
export const removeBook = mutation({
  args: { bookId: v.id("books") },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can remove books");
    }
    
    // Check if book has active borrowings
    const activeBorrowings = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_book", (q) => q.eq("bookId", args.bookId))
      .filter((q) => q.eq(q.field("status"), "borrowed"))
      .collect();
    
    if (activeBorrowings.length > 0) {
      throw new Error("Cannot remove book with active borrowings");
    }
    
    await ctx.db.delete(args.bookId);
  },
});

// Get popular books for recommendations
export const getPopularBooks = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;
    
    // Get books with most borrowings in the last 30 days
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    
    const recentBorrowings = await ctx.db
      .query("borrowingRecords")
      .filter((q) => q.gte(q.field("borrowDate"), thirtyDaysAgo))
      .collect();
    
    // Count borrowings per book
    const bookCounts = new Map<string, number>();
    recentBorrowings.forEach(record => {
      const count = bookCounts.get(record.bookId) || 0;
      bookCounts.set(record.bookId, count + 1);
    });
    
    // Sort by popularity and get book details
    const sortedBooks = Array.from(bookCounts.entries())
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit);
    
    const popularBooks = await Promise.all(
      sortedBooks.map(async ([bookId, borrowCount]) => {
        const book = await ctx.db.get(bookId as any);
        return book ? { ...book, borrowCount } : null;
      })
    );
    
    return popularBooks.filter(Boolean);
  },
});

// Get books by genre for recommendations
export const getBooksByGenre = query({
  args: { 
    genres: v.array(v.string()),
    limit: v.optional(v.number()),
    excludeBookIds: v.optional(v.array(v.id("books"))),
  },
  handler: async (ctx, args) => {
    const limit = args.limit || 5;
    const excludeIds = new Set(args.excludeBookIds || []);
    
    const books = [];
    
    for (const genre of args.genres) {
      const genreBooks = await ctx.db
        .query("books")
        .withIndex("by_genre", (q) => q.eq("genre", genre))
        .filter((q) => q.gt(q.field("availableCopies"), 0))
        .take(limit);
      
      const filteredBooks = genreBooks.filter(book => !excludeIds.has(book._id));
      books.push(...filteredBooks);
      
      if (books.length >= limit) break;
    }
    
    return books.slice(0, limit);
  },
});
