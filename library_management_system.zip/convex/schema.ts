import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Books table
  books: defineTable({
    title: v.string(),
    author: v.string(),
    isbn: v.string(),
    genre: v.string(),
    edition: v.string(),
    publishedYear: v.number(),
    totalCopies: v.number(),
    availableCopies: v.number(),
    description: v.optional(v.string()),
    coverImageId: v.optional(v.id("_storage")),
    addedBy: v.id("users"),
    tags: v.array(v.string()),
  })
    .index("by_title", ["title"])
    .index("by_author", ["author"])
    .index("by_genre", ["genre"])
    .index("by_isbn", ["isbn"])
    .searchIndex("search_books", {
      searchField: "title",
      filterFields: ["author", "genre"],
    }),

  // User profiles (extends auth users)
  userProfiles: defineTable({
    userId: v.id("users"),
    role: v.union(v.literal("admin"), v.literal("user")),
    firstName: v.string(),
    lastName: v.string(),
    phoneNumber: v.optional(v.string()),
    address: v.optional(v.string()),
    membershipDate: v.number(),
    isActive: v.boolean(),
    maxBooksAllowed: v.number(),
    fineAmount: v.number(),
    preferences: v.object({
      favoriteGenres: v.array(v.string()),
      notificationSettings: v.object({
        email: v.boolean(),
        sms: v.boolean(),
        dueDateReminders: v.boolean(),
      }),
    }),
  }).index("by_user_id", ["userId"]),

  // Borrowing records
  borrowingRecords: defineTable({
    userId: v.id("users"),
    bookId: v.id("books"),
    borrowDate: v.number(),
    dueDate: v.number(),
    returnDate: v.optional(v.number()),
    status: v.union(
      v.literal("borrowed"),
      v.literal("returned"),
      v.literal("overdue"),
      v.literal("reserved")
    ),
    fineAmount: v.number(),
    renewalCount: v.number(),
    notes: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_book", ["bookId"])
    .index("by_status", ["status"])
    .index("by_due_date", ["dueDate"]),

  // Book reservations
  reservations: defineTable({
    userId: v.id("users"),
    bookId: v.id("books"),
    reservationDate: v.number(),
    expiryDate: v.number(),
    status: v.union(
      v.literal("active"),
      v.literal("fulfilled"),
      v.literal("expired"),
      v.literal("cancelled")
    ),
    notificationSent: v.boolean(),
  })
    .index("by_user", ["userId"])
    .index("by_book", ["bookId"])
    .index("by_status", ["status"]),

  // User reading history and preferences for AI recommendations
  readingHistory: defineTable({
    userId: v.id("users"),
    bookId: v.id("books"),
    rating: v.optional(v.number()), // 1-5 stars
    review: v.optional(v.string()),
    readingDate: v.number(),
    readingDuration: v.optional(v.number()), // in days
    genres: v.array(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_book", ["bookId"])
    .index("by_rating", ["rating"]),

  // Notifications
  notifications: defineTable({
    userId: v.id("users"),
    type: v.union(
      v.literal("due_date_reminder"),
      v.literal("overdue_notice"),
      v.literal("book_available"),
      v.literal("fine_notice"),
      v.literal("system_update")
    ),
    title: v.string(),
    message: v.string(),
    isRead: v.boolean(),
    createdAt: v.number(),
    relatedBookId: v.optional(v.id("books")),
    relatedRecordId: v.optional(v.id("borrowingRecords")),
  })
    .index("by_user", ["userId"])
    .index("by_type", ["type"])
    .index("by_read_status", ["isRead"]),

  // System analytics
  analytics: defineTable({
    date: v.string(), // YYYY-MM-DD format
    totalBooks: v.number(),
    totalUsers: v.number(),
    booksIssued: v.number(),
    booksReturned: v.number(),
    overdueBooks: v.number(),
    finesCollected: v.number(),
    newRegistrations: v.number(),
    popularGenres: v.array(v.object({
      genre: v.string(),
      count: v.number(),
    })),
    topBooks: v.array(v.object({
      bookId: v.id("books"),
      borrowCount: v.number(),
    })),
  }).index("by_date", ["date"]),

  // AI chat sessions for the virtual assistant
  chatSessions: defineTable({
    userId: v.id("users"),
    sessionId: v.string(),
    messages: v.array(v.object({
      role: v.union(v.literal("user"), v.literal("assistant")),
      content: v.string(),
      timestamp: v.number(),
    })),
    isActive: v.boolean(),
    createdAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_session", ["sessionId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
