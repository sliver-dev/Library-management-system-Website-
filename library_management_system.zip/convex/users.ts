import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Helper function to get user profile
async function getUserProfile(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  
  const profile = await ctx.db
    .query("userProfiles")
    .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
    .unique();
  
  if (!profile) throw new Error("User profile not found");
  return { userId, profile };
}

// Create user profile after registration
export const createUserProfile = mutation({
  args: {
    firstName: v.string(),
    lastName: v.string(),
    phoneNumber: v.optional(v.string()),
    address: v.optional(v.string()),
    role: v.optional(v.union(v.literal("admin"), v.literal("user"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    // Check if profile already exists
    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();
    
    if (existingProfile) {
      throw new Error("User profile already exists");
    }
    
    const profileId = await ctx.db.insert("userProfiles", {
      userId,
      role: args.role || "user",
      firstName: args.firstName,
      lastName: args.lastName,
      phoneNumber: args.phoneNumber,
      address: args.address,
      membershipDate: Date.now(),
      isActive: true,
      maxBooksAllowed: 5,
      fineAmount: 0,
      preferences: {
        favoriteGenres: [],
        notificationSettings: {
          email: true,
          sms: false,
          dueDateReminders: true,
        },
      },
    });
    
    return profileId;
  },
});

// Get current user profile
export const getCurrentUserProfile = query({
  args: {},
  handler: async (ctx) => {
    const { userId, profile } = await getUserProfile(ctx);
    
    const user = await ctx.db.get(userId);
    return {
      ...profile,
      email: user?.email,
    };
  },
});

// Update user profile
export const updateUserProfile = mutation({
  args: {
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    phoneNumber: v.optional(v.string()),
    address: v.optional(v.string()),
    preferences: v.optional(v.object({
      favoriteGenres: v.array(v.string()),
      notificationSettings: v.object({
        email: v.boolean(),
        sms: v.boolean(),
        dueDateReminders: v.boolean(),
      }),
    })),
  },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    const updates: any = {};
    if (args.firstName !== undefined) updates.firstName = args.firstName;
    if (args.lastName !== undefined) updates.lastName = args.lastName;
    if (args.phoneNumber !== undefined) updates.phoneNumber = args.phoneNumber;
    if (args.address !== undefined) updates.address = args.address;
    if (args.preferences !== undefined) updates.preferences = args.preferences;
    
    await ctx.db.patch(profile._id, updates);
  },
});

// Get all users (Admin only)
export const getAllUsers = query({
  args: {
    isActive: v.optional(v.boolean()),
    role: v.optional(v.union(v.literal("admin"), v.literal("user"))),
  },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view all users");
    }
    
    let query = ctx.db.query("userProfiles");
    
    const profiles = await query.collect();
    
    // Filter by criteria
    let filteredProfiles = profiles;
    if (args.isActive !== undefined) {
      filteredProfiles = filteredProfiles.filter(p => p.isActive === args.isActive);
    }
    if (args.role !== undefined) {
      filteredProfiles = filteredProfiles.filter(p => p.role === args.role);
    }
    
    // Get user details for each profile
    const usersWithDetails = await Promise.all(
      filteredProfiles.map(async (profile) => {
        const user = await ctx.db.get(profile.userId);
        
        // Get borrowing stats
        const activeBorrowings = await ctx.db
          .query("borrowingRecords")
          .withIndex("by_user", (q) => q.eq("userId", profile.userId))
          .filter((q) => q.eq(q.field("status"), "borrowed"))
          .collect();
        
        const overdueBooks = await ctx.db
          .query("borrowingRecords")
          .withIndex("by_user", (q) => q.eq("userId", profile.userId))
          .filter((q) => q.eq(q.field("status"), "overdue"))
          .collect();
        
        return {
          ...profile,
          email: user?.email,
          activeBorrowings: activeBorrowings.length,
          overdueBooks: overdueBooks.length,
        };
      })
    );
    
    return usersWithDetails;
  },
});

// Update user status (Admin only)
export const updateUserStatus = mutation({
  args: {
    userId: v.id("users"),
    isActive: v.boolean(),
    maxBooksAllowed: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can update user status");
    }
    
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", args.userId))
      .unique();
    
    if (!userProfile) {
      throw new Error("User profile not found");
    }
    
    const updates: any = { isActive: args.isActive };
    if (args.maxBooksAllowed !== undefined) {
      updates.maxBooksAllowed = args.maxBooksAllowed;
    }
    
    await ctx.db.patch(userProfile._id, updates);
  },
});

// Get user borrowing history
export const getUserBorrowingHistory = query({
  args: { 
    userId: v.optional(v.id("users")),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { userId: currentUserId, profile } = await getUserProfile(ctx);
    
    // Users can only see their own history, admins can see any user's history
    const targetUserId = args.userId || currentUserId;
    if (profile.role !== "admin" && targetUserId !== currentUserId) {
      throw new Error("Access denied");
    }
    
    const limit = args.limit || 50;
    
    const borrowingRecords = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_user", (q) => q.eq("userId", targetUserId))
      .order("desc")
      .take(limit);
    
    // Get book details for each record
    const historyWithBooks = await Promise.all(
      borrowingRecords.map(async (record) => {
        const book = await ctx.db.get(record.bookId);
        return {
          ...record,
          book,
        };
      })
    );
    
    return historyWithBooks;
  },
});

// Update user fine amount (Admin only)
export const updateUserFine = mutation({
  args: {
    userId: v.id("users"),
    fineAmount: v.number(),
    action: v.union(v.literal("add"), v.literal("subtract"), v.literal("set")),
  },
  handler: async (ctx, args) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can update fines");
    }
    
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", args.userId))
      .unique();
    
    if (!userProfile) {
      throw new Error("User profile not found");
    }
    
    let newFineAmount = userProfile.fineAmount;
    
    switch (args.action) {
      case "add":
        newFineAmount += args.fineAmount;
        break;
      case "subtract":
        newFineAmount = Math.max(0, newFineAmount - args.fineAmount);
        break;
      case "set":
        newFineAmount = Math.max(0, args.fineAmount);
        break;
    }
    
    await ctx.db.patch(userProfile._id, { fineAmount: newFineAmount });
    
    return newFineAmount;
  },
});
