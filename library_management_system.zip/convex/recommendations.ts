import { query, action } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

// Helper function to get user profile
async function getUserProfile(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  
  const profile = await ctx.db
    .query("userProfiles")
    .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
    .unique();
  
  if (!profile) throw new Error("User profile not found");
  return { userId, profile };
}

// Get personalized book recommendations
export const getPersonalizedRecommendations = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args): Promise<any[]> => {
    const { userId, profile } = await getUserProfile(ctx);
    const limit = args.limit || 10;
    
    // Get user's reading history
    const readingHistory = await ctx.db
      .query("readingHistory")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    
    // Get user's borrowing history
    const borrowingHistory = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    
    // Extract favorite genres from reading history and preferences
    const genreFrequency = new Map<string, number>();
    
    // Count genres from reading history
    readingHistory.forEach(record => {
      record.genres.forEach(genre => {
        genreFrequency.set(genre, (genreFrequency.get(genre) || 0) + 1);
      });
    });
    
    // Add preferred genres
    profile.preferences.favoriteGenres.forEach((genre: string) => {
      genreFrequency.set(genre, (genreFrequency.get(genre) || 0) + 2); // Weight preferences higher
    });
    
    // Get books from borrowing history to exclude
    const borrowedBookIds = new Set(borrowingHistory.map(record => record.bookId));
    
    // Get top genres
    const topGenres = Array.from(genreFrequency.entries())
      .sort(([, a], [, b]) => b - a)
      .slice(0, 3)
      .map(([genre]) => genre);
    
    if (topGenres.length === 0) {
      // New user - return popular books
      return await ctx.runQuery(api.books.getPopularBooks, { limit });
    }
    
    // Get books from favorite genres
    const recommendations: any[] = await ctx.runQuery(api.books.getBooksByGenre, {
      genres: topGenres,
      limit,
      excludeBookIds: Array.from(borrowedBookIds),
    });
    
    return recommendations;
  },
});

// AI-powered book search with natural language processing
export const aiBookSearch = action({
  args: { 
    query: v.string(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args): Promise<any[]> => {
    const limit = args.limit || 10;
    
    // Use OpenAI to parse the natural language query
    const openai = new (await import("openai")).default({
      baseURL: process.env.CONVEX_OPENAI_BASE_URL,
      apiKey: process.env.CONVEX_OPENAI_API_KEY,
    });
    
    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        {
          role: "system",
          content: `You are a library search assistant. Parse the user's natural language query and extract:
          1. Keywords for title/author search
          2. Genre preferences
          3. Any specific criteria
          
          Return a JSON object with:
          {
            "searchTerm": "main keywords for search",
            "genre": "specific genre if mentioned",
            "author": "author name if mentioned",
            "criteria": "any other specific requirements"
          }
          
          If no specific criteria is mentioned, return null for that field.`
        },
        {
          role: "user",
          content: args.query
        }
      ],
    });
    
    let searchParams;
    try {
      searchParams = JSON.parse(response.choices[0].message.content || "{}");
    } catch {
      // Fallback to simple search
      searchParams = { searchTerm: args.query };
    }
    
    // Search books using extracted parameters
    const books: any[] = await ctx.runQuery(api.books.searchBooks, {
      searchTerm: searchParams.searchTerm,
      genre: searchParams.genre,
      author: searchParams.author,
      availableOnly: true,
    });
    
    return books.slice(0, limit);
  },
});

// Get similar books based on a specific book
export const getSimilarBooks = query({
  args: { 
    bookId: v.id("books"),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit || 5;
    
    const book = await ctx.db.get(args.bookId);
    if (!book) return [];
    
    // Find books by same author
    const sameAuthorBooks = await ctx.db
      .query("books")
      .withIndex("by_author", (q) => q.eq("author", book.author))
      .filter((q) => 
        q.and(
          q.neq(q.field("_id"), args.bookId),
          q.gt(q.field("availableCopies"), 0)
        )
      )
      .take(3);
    
    // Find books in same genre
    const sameGenreBooks = await ctx.db
      .query("books")
      .withIndex("by_genre", (q) => q.eq("genre", book.genre))
      .filter((q) => 
        q.and(
          q.neq(q.field("_id"), args.bookId),
          q.neq(q.field("author"), book.author),
          q.gt(q.field("availableCopies"), 0)
        )
      )
      .take(limit - sameAuthorBooks.length);
    
    return [...sameAuthorBooks, ...sameGenreBooks].slice(0, limit);
  },
});

// Get trending books based on recent activity
export const getTrendingBooks = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;
    
    // Get books borrowed in the last 7 days
    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    
    const recentBorrowings = await ctx.db
      .query("borrowingRecords")
      .filter((q) => q.gte(q.field("borrowDate"), weekAgo))
      .collect();
    
    // Count borrowings per book
    const bookCounts = new Map<string, number>();
    recentBorrowings.forEach(record => {
      const count = bookCounts.get(record.bookId) || 0;
      bookCounts.set(record.bookId, count + 1);
    });
    
    // Sort by trend and get book details
    const trendingBookIds = Array.from(bookCounts.entries())
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit)
      .map(([bookId]) => bookId);
    
    const trendingBooks = await Promise.all(
      trendingBookIds.map(async (bookId) => {
        const book = await ctx.db.get(bookId as any);
        return book ? { ...book, trendScore: bookCounts.get(bookId) } : null;
      })
    );
    
    return trendingBooks.filter(Boolean);
  },
});

// Get new arrivals
export const getNewArrivals = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;
    
    // Get books added in the last 30 days
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    
    const newBooks = await ctx.db
      .query("books")
      .filter((q) => q.gte(q.field("_creationTime"), thirtyDaysAgo))
      .order("desc")
      .take(limit);
    
    return newBooks;
  },
});

// Update user reading preferences based on activity
export const updateReadingPreferences = action({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    // Get user's recent reading history
    const recentHistory = await ctx.runQuery(api.users.getUserBorrowingHistory, {
      userId,
      limit: 20,
    });
    
    // Analyze genre preferences
    const genreFrequency = new Map<string, number>();
    recentHistory.forEach((record: any) => {
      if (record.book) {
        const genre = record.book.genre;
        genreFrequency.set(genre, (genreFrequency.get(genre) || 0) + 1);
      }
    });
    
    // Get top 5 genres
    const favoriteGenres = Array.from(genreFrequency.entries())
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([genre]) => genre);
    
    // Update user preferences
    await ctx.runMutation(api.users.updateUserProfile, {
      preferences: {
        favoriteGenres,
        notificationSettings: {
          email: true,
          sms: false,
          dueDateReminders: true,
        },
      },
    });
    
    return favoriteGenres;
  },
});
