import { query, mutation, internalMutation, internalAction } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";
import { api } from "./_generated/api";

// Helper function to get user profile
async function getUserProfile(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  
  const profile = await ctx.db
    .query("userProfiles")
    .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
    .unique();
  
  if (!profile) throw new Error("User profile not found");
  return { userId, profile };
}

// Create notification (internal)
export const createNotification = internalMutation({
  args: {
    userId: v.id("users"),
    type: v.union(
      v.literal("due_date_reminder"),
      v.literal("overdue_notice"),
      v.literal("book_available"),
      v.literal("fine_notice"),
      v.literal("system_update")
    ),
    title: v.string(),
    message: v.string(),
    relatedBookId: v.optional(v.id("books")),
    relatedRecordId: v.optional(v.id("borrowingRecords")),
  },
  handler: async (ctx, args) => {
    const notificationId = await ctx.db.insert("notifications", {
      ...args,
      isRead: false,
      createdAt: Date.now(),
    });
    
    return notificationId;
  },
});

// Get user notifications
export const getUserNotifications = query({
  args: { 
    unreadOnly: v.optional(v.boolean()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { userId } = await getUserProfile(ctx);
    const limit = args.limit || 50;
    
    let query = ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", userId));
    
    if (args.unreadOnly) {
      query = query.filter((q) => q.eq(q.field("isRead"), false));
    }
    
    const notifications = await query
      .order("desc")
      .take(limit);
    
    // Get related book details
    const notificationsWithDetails = await Promise.all(
      notifications.map(async (notification) => {
        let book = null;
        if (notification.relatedBookId) {
          book = await ctx.db.get(notification.relatedBookId);
        }
        
        return {
          ...notification,
          book,
        };
      })
    );
    
    return notificationsWithDetails;
  },
});

// Mark notification as read
export const markNotificationAsRead = mutation({
  args: { notificationId: v.id("notifications") },
  handler: async (ctx, args) => {
    const { userId } = await getUserProfile(ctx);
    
    const notification = await ctx.db.get(args.notificationId);
    if (!notification) throw new Error("Notification not found");
    
    if (notification.userId !== userId) {
      throw new Error("Access denied");
    }
    
    await ctx.db.patch(args.notificationId, { isRead: true });
  },
});

// Mark all notifications as read
export const markAllNotificationsAsRead = mutation({
  args: {},
  handler: async (ctx) => {
    const { userId } = await getUserProfile(ctx);
    
    const unreadNotifications = await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("isRead"), false))
      .collect();
    
    await Promise.all(
      unreadNotifications.map(notification =>
        ctx.db.patch(notification._id, { isRead: true })
      )
    );
    
    return unreadNotifications.length;
  },
});

// Send due date reminder (internal, scheduled)
export const sendDueDateReminder = internalAction({
  args: { recordId: v.id("borrowingRecords") },
  handler: async (ctx, args) => {
    const record = await ctx.runQuery(api.notifications.getBorrowingRecord, {
      recordId: args.recordId,
    });
    
    if (!record || record.status !== "borrowed") {
      return; // Book already returned or status changed
    }
    
    const book = await ctx.runQuery(api.notifications.getBook, {
      bookId: record.bookId,
    });
    
    if (!book) return;
    
    const daysUntilDue = Math.ceil((record.dueDate - Date.now()) / (24 * 60 * 60 * 1000));
    
    await ctx.runMutation(internal.notifications.createNotification, {
      userId: record.userId,
      type: "due_date_reminder",
      title: "Book Due Soon",
      message: `"${book.title}" is due in ${daysUntilDue} day(s). Please return or renew it.`,
      relatedBookId: record.bookId,
      relatedRecordId: args.recordId,
    });
  },
});

// Helper queries for internal use
export const getBorrowingRecord = query({
  args: { recordId: v.id("borrowingRecords") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.recordId);
  },
});

export const getBook = query({
  args: { bookId: v.id("books") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.bookId);
  },
});

// Send overdue notices (scheduled daily)
export const sendOverdueNotices = internalAction({
  args: {},
  handler: async (ctx) => {
    // Get all overdue books
    const overdueRecords = await ctx.runQuery(api.notifications.getOverdueRecords);
    
    for (const record of overdueRecords) {
      const book = await ctx.runQuery(api.notifications.getBook, {
        bookId: record.bookId,
      });
      
      if (!book) continue;
      
      const daysOverdue = Math.ceil((Date.now() - record.dueDate) / (24 * 60 * 60 * 1000));
      const fineAmount = daysOverdue * 1; // $1 per day
      
      // Check if we already sent a notice today
      const today = new Date().toISOString().split('T')[0];
      const existingNotice = await ctx.runQuery(api.notifications.getTodaysOverdueNotice, {
        userId: record.userId,
        bookId: record.bookId,
        date: today,
      });
      
      if (!existingNotice) {
        await ctx.runMutation(internal.notifications.createNotification, {
          userId: record.userId,
          type: "overdue_notice",
          title: "Overdue Book",
          message: `"${book.title}" is ${daysOverdue} day(s) overdue. Fine: $${fineAmount.toFixed(2)}`,
          relatedBookId: record.bookId,
          relatedRecordId: record._id,
        });
      }
    }
  },
});

// Helper queries
export const getOverdueRecords = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("borrowingRecords")
      .withIndex("by_status", (q) => q.eq("status", "overdue"))
      .collect();
  },
});

export const getTodaysOverdueNotice = query({
  args: {
    userId: v.id("users"),
    bookId: v.id("books"),
    date: v.string(),
  },
  handler: async (ctx, args) => {
    const startOfDay = new Date(args.date).getTime();
    const endOfDay = startOfDay + 24 * 60 * 60 * 1000;
    
    return await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .filter((q) => 
        q.and(
          q.eq(q.field("type"), "overdue_notice"),
          q.eq(q.field("relatedBookId"), args.bookId),
          q.gte(q.field("createdAt"), startOfDay),
          q.lt(q.field("createdAt"), endOfDay)
        )
      )
      .first();
  },
});

// Get notification statistics (Admin only)
export const getNotificationStats = query({
  args: {},
  handler: async (ctx) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view notification stats");
    }
    
    const last30Days = Date.now() - 30 * 24 * 60 * 60 * 1000;
    
    const recentNotifications = await ctx.db
      .query("notifications")
      .filter((q) => q.gte(q.field("createdAt"), last30Days))
      .collect();
    
    const stats = {
      total: recentNotifications.length,
      byType: {} as Record<string, number>,
      unreadCount: 0,
    };
    
    recentNotifications.forEach(notification => {
      stats.byType[notification.type] = (stats.byType[notification.type] || 0) + 1;
      if (!notification.isRead) {
        stats.unreadCount++;
      }
    });
    
    return stats;
  },
});
