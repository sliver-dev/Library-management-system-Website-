import { cronJobs } from "convex/server";
import { internal } from "./_generated/api";

const crons = cronJobs();

// Update daily analytics every day at midnight
crons.cron("update daily analytics", "0 0 * * *", internal.analytics.updateDailyAnalytics, {});

// Send overdue notices every day at 9 AM
crons.cron("send overdue notices", "0 9 * * *", internal.notifications.sendOverdueNotices, {});

export default crons;
