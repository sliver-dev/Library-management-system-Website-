import { query, mutation, action } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

// Helper function to get user profile
async function getUserProfile(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  
  const profile = await ctx.db
    .query("userProfiles")
    .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
    .unique();
  
  if (!profile) throw new Error("User profile not found");
  return { userId, profile };
}

// Start a new chat session
export const startChatSession = mutation({
  args: {},
  handler: async (ctx) => {
    const { userId } = await getUserProfile(ctx);
    
    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const chatId = await ctx.db.insert("chatSessions", {
      userId,
      sessionId,
      messages: [{
        role: "assistant",
        content: "Hello! I'm your library assistant. I can help you find books, check due dates, calculate fines, and answer questions about library services. How can I assist you today?",
        timestamp: Date.now(),
      }],
      isActive: true,
      createdAt: Date.now(),
    });
    
    return { chatId, sessionId };
  },
});

// Send message to AI assistant
export const sendChatMessage = action({
  args: {
    sessionId: v.string(),
    message: v.string(),
  },
  handler: async (ctx, args): Promise<string> => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    // Get chat session
    const chatSession: any = await ctx.runQuery(api.chat.getChatSession, {
      sessionId: args.sessionId,
    });
    
    if (!chatSession || chatSession.userId !== userId) {
      throw new Error("Chat session not found or access denied");
    }
    
    // Add user message
    const updatedMessages: any[] = [
      ...chatSession.messages,
      {
        role: "user" as const,
        content: args.message,
        timestamp: Date.now(),
      }
    ];
    
    // Get user context for AI
    const userProfile: any = await ctx.runQuery(api.users.getCurrentUserProfile);
    const currentBorrowings: any[] = await ctx.runQuery(api.borrowing.getCurrentBorrowings);
    const notifications: any[] = await ctx.runQuery(api.notifications.getUserNotifications, {
      unreadOnly: true,
      limit: 5,
    });
    
    // Prepare context for AI
    const context: any = {
      userProfile,
      currentBorrowings: currentBorrowings.map((b: any) => ({
        book: b.book?.title,
        dueDate: new Date(b.dueDate).toLocaleDateString(),
        isOverdue: b.isOverdue,
        daysOverdue: b.daysOverdue,
      })),
      notifications: notifications.map((n: any) => ({
        type: n.type,
        title: n.title,
        message: n.message,
      })),
    };
    
    // Generate AI response
    const openai = new (await import("openai")).default({
      baseURL: process.env.CONVEX_OPENAI_BASE_URL,
      apiKey: process.env.CONVEX_OPENAI_API_KEY,
    });
    
    const systemPrompt: string = `You are a helpful library assistant AI. You can help users with:
    
    1. Finding books and recommendations
    2. Checking due dates and renewals
    3. Calculating fines and fees
    4. Library policies and procedures
    5. Account information and borrowing history
    
    Current user context:
    - Name: ${userProfile?.firstName} ${userProfile?.lastName}
    - Role: ${userProfile?.role}
    - Fine Amount: $${userProfile?.fineAmount || 0}
    - Current Borrowings: ${context.currentBorrowings.length} books
    - Unread Notifications: ${context.notifications.length}
    
    Current borrowed books:
    ${context.currentBorrowings.map((b: any) => 
      `- "${b.book}" (Due: ${b.dueDate}${b.isOverdue ? ` - OVERDUE by ${b.daysOverdue} days` : ''})`
    ).join('\n')}
    
    Recent notifications:
    ${context.notifications.map((n: any) => `- ${n.title}: ${n.message}`).join('\n')}
    
    Be helpful, concise, and friendly. If asked about specific books or library functions, 
    provide accurate information based on the context. For book searches or recommendations,
    suggest using the search and recommendation features in the app.`;
    
    const response: any = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        { role: "system", content: systemPrompt },
        ...updatedMessages.slice(-10), // Keep last 10 messages for context
      ],
      max_tokens: 500,
    });
    
    const aiResponse: string = response.choices[0].message.content || "I'm sorry, I couldn't process that request.";
    
    // Add AI response
    const finalMessages = [
      ...updatedMessages,
      {
        role: "assistant" as const,
        content: aiResponse,
        timestamp: Date.now(),
      }
    ];
    
    // Update chat session
    await ctx.runMutation(api.chat.updateChatSession, {
      sessionId: args.sessionId,
      messages: finalMessages,
    });
    
    return aiResponse;
  },
});

// Get chat session
export const getChatSession = query({
  args: { sessionId: v.string() },
  handler: async (ctx, args) => {
    const { userId } = await getUserProfile(ctx);
    
    const chatSession = await ctx.db
      .query("chatSessions")
      .withIndex("by_session", (q) => q.eq("sessionId", args.sessionId))
      .unique();
    
    if (!chatSession || chatSession.userId !== userId) {
      return null;
    }
    
    return chatSession;
  },
});

// Update chat session
export const updateChatSession = mutation({
  args: {
    sessionId: v.string(),
    messages: v.array(v.object({
      role: v.union(v.literal("user"), v.literal("assistant")),
      content: v.string(),
      timestamp: v.number(),
    })),
  },
  handler: async (ctx, args) => {
    const { userId } = await getUserProfile(ctx);
    
    const chatSession = await ctx.db
      .query("chatSessions")
      .withIndex("by_session", (q) => q.eq("sessionId", args.sessionId))
      .unique();
    
    if (!chatSession || chatSession.userId !== userId) {
      throw new Error("Chat session not found or access denied");
    }
    
    await ctx.db.patch(chatSession._id, {
      messages: args.messages,
    });
  },
});

// Get user's chat sessions
export const getUserChatSessions = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const { userId } = await getUserProfile(ctx);
    const limit = args.limit || 10;
    
    const sessions = await ctx.db
      .query("chatSessions")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(limit);
    
    return sessions.map(session => ({
      sessionId: session.sessionId,
      createdAt: session.createdAt,
      isActive: session.isActive,
      lastMessage: session.messages[session.messages.length - 1],
      messageCount: session.messages.length,
    }));
  },
});

// End chat session
export const endChatSession = mutation({
  args: { sessionId: v.string() },
  handler: async (ctx, args) => {
    const { userId } = await getUserProfile(ctx);
    
    const chatSession = await ctx.db
      .query("chatSessions")
      .withIndex("by_session", (q) => q.eq("sessionId", args.sessionId))
      .unique();
    
    if (!chatSession || chatSession.userId !== userId) {
      throw new Error("Chat session not found or access denied");
    }
    
    await ctx.db.patch(chatSession._id, { isActive: false });
  },
});
