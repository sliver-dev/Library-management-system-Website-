import { query, mutation, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";

// Helper function to get user profile
async function getUserProfile(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  
  const profile = await ctx.db
    .query("userProfiles")
    .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
    .unique();
  
  if (!profile) throw new Error("User profile not found");
  return { userId, profile };
}

// Borrow a book
export const borrowBook = mutation({
  args: { 
    bookId: v.id("books"),
    borrowDays: v.optional(v.number()), // Default 14 days
  },
  handler: async (ctx, args) => {
    const { userId, profile } = await getUserProfile(ctx);
    
    if (!profile.isActive) {
      throw new Error("Account is inactive");
    }
    
    // Check if user has outstanding fines
    if (profile.fineAmount > 0) {
      throw new Error("Please pay outstanding fines before borrowing");
    }
    
    // Check current borrowing limit
    const activeBorrowings = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("status"), "borrowed"))
      .collect();
    
    if (activeBorrowings.length >= profile.maxBooksAllowed) {
      throw new Error(`Maximum borrowing limit (${profile.maxBooksAllowed}) reached`);
    }
    
    // Check book availability
    const book = await ctx.db.get(args.bookId);
    if (!book) throw new Error("Book not found");
    
    if (book.availableCopies <= 0) {
      throw new Error("Book is not available");
    }
    
    // Check if user already has this book borrowed
    const existingBorrowing = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => 
        q.and(
          q.eq(q.field("bookId"), args.bookId),
          q.eq(q.field("status"), "borrowed")
        )
      )
      .first();
    
    if (existingBorrowing) {
      throw new Error("You already have this book borrowed");
    }
    
    const borrowDays = args.borrowDays || 14;
    const borrowDate = Date.now();
    const dueDate = borrowDate + (borrowDays * 24 * 60 * 60 * 1000);
    
    // Create borrowing record
    const recordId = await ctx.db.insert("borrowingRecords", {
      userId,
      bookId: args.bookId,
      borrowDate,
      dueDate,
      status: "borrowed",
      fineAmount: 0,
      renewalCount: 0,
    });
    
    // Update book availability
    await ctx.db.patch(args.bookId, {
      availableCopies: book.availableCopies - 1,
    });
    
    // Schedule due date reminder
    await ctx.scheduler.runAfter(
      (borrowDays - 2) * 24 * 60 * 60 * 1000, // 2 days before due
      internal.notifications.sendDueDateReminder,
      { recordId }
    );
    
    return recordId;
  },
});

// Return a book
export const returnBook = mutation({
  args: { recordId: v.id("borrowingRecords") },
  handler: async (ctx, args) => {
    const { userId, profile } = await getUserProfile(ctx);
    
    const record = await ctx.db.get(args.recordId);
    if (!record) throw new Error("Borrowing record not found");
    
    // Check ownership or admin privileges
    if (record.userId !== userId && profile.role !== "admin") {
      throw new Error("Access denied");
    }
    
    if (record.status !== "borrowed" && record.status !== "overdue") {
      throw new Error("Book is not currently borrowed");
    }
    
    const returnDate = Date.now();
    let fineAmount = 0;
    
    // Calculate fine if overdue
    if (returnDate > record.dueDate) {
      const overdueDays = Math.ceil((returnDate - record.dueDate) / (24 * 60 * 60 * 1000));
      fineAmount = overdueDays * 1; // $1 per day fine
    }
    
    // Update borrowing record
    await ctx.db.patch(args.recordId, {
      returnDate,
      status: "returned",
      fineAmount,
    });
    
    // Update book availability
    const book = await ctx.db.get(record.bookId);
    if (book) {
      await ctx.db.patch(record.bookId, {
        availableCopies: book.availableCopies + 1,
      });
    }
    
    // Add fine to user profile if applicable
    if (fineAmount > 0) {
      const userProfile = await ctx.db
        .query("userProfiles")
        .withIndex("by_user_id", (q) => q.eq("userId", record.userId))
        .unique();
      
      if (userProfile) {
        await ctx.db.patch(userProfile._id, {
          fineAmount: userProfile.fineAmount + fineAmount,
        });
      }
    }
    
    // Add to reading history
    await ctx.db.insert("readingHistory", {
      userId: record.userId,
      bookId: record.bookId,
      readingDate: returnDate,
      readingDuration: Math.ceil((returnDate - record.borrowDate) / (24 * 60 * 60 * 1000)),
      genres: book ? [book.genre] : [],
    });
    
    // Check if anyone is waiting for this book
    const activeReservation = await ctx.db
      .query("reservations")
      .withIndex("by_book", (q) => q.eq("bookId", record.bookId))
      .filter((q) => q.eq(q.field("status"), "active"))
      .order("asc") // First come, first served
      .first();
    
    if (activeReservation) {
      // Notify user that book is available
      await ctx.runMutation(internal.notifications.createNotification, {
        userId: activeReservation.userId,
        type: "book_available",
        title: "Reserved Book Available",
        message: `Your reserved book "${book?.title}" is now available for pickup.`,
        relatedBookId: record.bookId,
      });
    }
    
    return { fineAmount, returnDate };
  },
});

// Renew a borrowed book
export const renewBook = mutation({
  args: { 
    recordId: v.id("borrowingRecords"),
    renewalDays: v.optional(v.number()), // Default 14 days
  },
  handler: async (ctx, args) => {
    const { userId, profile } = await getUserProfile(ctx);
    
    const record = await ctx.db.get(args.recordId);
    if (!record) throw new Error("Borrowing record not found");
    
    // Check ownership
    if (record.userId !== userId) {
      throw new Error("Access denied");
    }
    
    if (record.status !== "borrowed") {
      throw new Error("Book is not currently borrowed");
    }
    
    // Check renewal limit (max 2 renewals)
    if (record.renewalCount >= 2) {
      throw new Error("Maximum renewal limit reached");
    }
    
    // Check if book has reservations
    const activeReservations = await ctx.db
      .query("reservations")
      .withIndex("by_book", (q) => q.eq("bookId", record.bookId))
      .filter((q) => q.eq(q.field("status"), "active"))
      .collect();
    
    if (activeReservations.length > 0) {
      throw new Error("Cannot renew - book has pending reservations");
    }
    
    const renewalDays = args.renewalDays || 14;
    const newDueDate = record.dueDate + (renewalDays * 24 * 60 * 60 * 1000);
    
    await ctx.db.patch(args.recordId, {
      dueDate: newDueDate,
      renewalCount: record.renewalCount + 1,
    });
    
    return { newDueDate, renewalCount: record.renewalCount + 1 };
  },
});

// Reserve a book
export const reserveBook = mutation({
  args: { bookId: v.id("books") },
  handler: async (ctx, args) => {
    const { userId, profile } = await getUserProfile(ctx);
    
    if (!profile.isActive) {
      throw new Error("Account is inactive");
    }
    
    const book = await ctx.db.get(args.bookId);
    if (!book) throw new Error("Book not found");
    
    // Check if book is available
    if (book.availableCopies > 0) {
      throw new Error("Book is available - no need to reserve");
    }
    
    // Check if user already has a reservation for this book
    const existingReservation = await ctx.db
      .query("reservations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => 
        q.and(
          q.eq(q.field("bookId"), args.bookId),
          q.eq(q.field("status"), "active")
        )
      )
      .first();
    
    if (existingReservation) {
      throw new Error("You already have a reservation for this book");
    }
    
    const reservationDate = Date.now();
    const expiryDate = reservationDate + (7 * 24 * 60 * 60 * 1000); // 7 days to pick up
    
    const reservationId = await ctx.db.insert("reservations", {
      userId,
      bookId: args.bookId,
      reservationDate,
      expiryDate,
      status: "active",
      notificationSent: false,
    });
    
    return reservationId;
  },
});

// Get user's current borrowings
export const getCurrentBorrowings = query({
  args: {},
  handler: async (ctx) => {
    const { userId } = await getUserProfile(ctx);
    
    const borrowings = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => 
        q.or(
          q.eq(q.field("status"), "borrowed"),
          q.eq(q.field("status"), "overdue")
        )
      )
      .collect();
    
    // Get book details and check for overdue
    const borrowingsWithBooks = await Promise.all(
      borrowings.map(async (record) => {
        const book = await ctx.db.get(record.bookId);
        const isOverdue = Date.now() > record.dueDate;
        
        return {
          ...record,
          book,
          isOverdue,
          daysOverdue: isOverdue ? Math.ceil((Date.now() - record.dueDate) / (24 * 60 * 60 * 1000)) : 0,
        };
      })
    );
    
    return borrowingsWithBooks;
  },
});

// Get user's reservations
export const getUserReservations = query({
  args: {},
  handler: async (ctx) => {
    const { userId } = await getUserProfile(ctx);
    
    const reservations = await ctx.db
      .query("reservations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("status"), "active"))
      .collect();
    
    // Get book details and queue position
    const reservationsWithDetails = await Promise.all(
      reservations.map(async (reservation) => {
        const book = await ctx.db.get(reservation.bookId);
        
        // Get queue position
        const earlierReservations = await ctx.db
          .query("reservations")
          .withIndex("by_book", (q) => q.eq("bookId", reservation.bookId))
          .filter((q) => 
            q.and(
              q.eq(q.field("status"), "active"),
              q.lt(q.field("reservationDate"), reservation.reservationDate)
            )
          )
          .collect();
        
        return {
          ...reservation,
          book,
          queuePosition: earlierReservations.length + 1,
        };
      })
    );
    
    return reservationsWithDetails;
  },
});

// Get overdue books (Admin only)
export const getOverdueBooks = query({
  args: {},
  handler: async (ctx) => {
    const { profile } = await getUserProfile(ctx);
    
    if (profile.role !== "admin") {
      throw new Error("Only admins can view overdue books");
    }
    
    const overdueRecords = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_status", (q) => q.eq("status", "overdue"))
      .collect();
    
    // Also check for books that should be marked overdue
    const borrowedRecords = await ctx.db
      .query("borrowingRecords")
      .withIndex("by_status", (q) => q.eq("status", "borrowed"))
      .filter((q) => q.lt(q.field("dueDate"), Date.now()))
      .collect();
    
    const allOverdueRecords = [...overdueRecords, ...borrowedRecords];
    
    // Get book and user details
    const overdueWithDetails = await Promise.all(
      allOverdueRecords.map(async (record) => {
        const book = await ctx.db.get(record.bookId);
        const userProfile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user_id", (q: any) => q.eq("userId", record.userId))
          .unique();
        const user = await ctx.db.get(record.userId);
        
        return {
          ...record,
          book,
          user: {
            ...userProfile,
            email: user?.email,
          },
          daysOverdue: Math.ceil((Date.now() - record.dueDate) / (24 * 60 * 60 * 1000)),
        };
      })
    );
    
    return overdueWithDetails;
  },
});
